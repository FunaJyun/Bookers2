# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '41597fec3e1854d6ec643daea2f168962a542e5a8f34dc2f4424adfc5bd49c2c9fad2b7b7ccdf31b06d382177df8f8fe2b8b7f42b9d88781f306ab4e438ed672'
